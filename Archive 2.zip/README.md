# Product Info and Reviews React Comoponent

### Installing

To install dependencies, webpack and seed data:

```
npm install
npm run build
npm run seeddata
```
