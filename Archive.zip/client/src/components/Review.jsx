import React from 'react';

export default class Review extends React.Component {
  constructor(props) {
    super(props);
  }

  render() {
    return (
      <div>
        <p>hello from review component</p>
      </div>
    );
  }
}
